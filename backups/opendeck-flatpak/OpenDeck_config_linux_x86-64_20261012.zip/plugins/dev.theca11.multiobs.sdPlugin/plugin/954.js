"use strict";
(self["webpackChunkmulti_obs_controller_sdplugin"] = self["webpackChunkmulti_obs_controller_sdplugin"] || []).push([[954],{

/***/ 5954:
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"144\" height=\"144\"><path fill=\"#efefef\" d=\"M32 92v6c0 3.311 2.689 6 6 6h6v-4h-6a2 2 0 01-2-2v-6h-4zm80 0h-4v6a2 2 0 01-2 2h-6v4h6c3.311 0 6-2.689 6-6v-6zm-12-52v4h6a2 2 0 012 2v6h4v-6c0-3.311-2.689-6-6-6h-6zm-56 0h-6c-3.311 0-6 2.689-6 6v6h4v-6a2 2 0 012-2h6v-4zm38 14c0-3.311-2.689-6-6-6h-8c-3.311 0-6 2.689-6 6H50c-3.311 0-6 2.689-6 6v28c0 3.311 2.689 6 6 6h44c3.311 0 6-2.689 6-6V60c0-3.311-2.689-6-6-6H82zm-10 4c8.831 0 16 7.169 16 16s-7.169 16-16 16-16-7.169-16-16 7.169-16 16-16zm-5 8a3.001 3.001 0 010 6 3.001 3.001 0 010-6zm25-8a2 2 0 11-.001 4.001A2 2 0 0192 58z\"/></svg>";

/***/ })

}]);