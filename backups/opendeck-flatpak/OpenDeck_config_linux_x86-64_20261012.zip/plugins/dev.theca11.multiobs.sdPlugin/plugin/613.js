"use strict";
(self["webpackChunkmulti_obs_controller_sdplugin"] = self["webpackChunkmulti_obs_controller_sdplugin"] || []).push([[613],{

/***/ 3613:
/***/ ((module) => {

module.exports = "<svg width=\"144\" height=\"144\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#efefef\" d=\"M80 104V44c0-2.211-1.789-4-4-4h-8c-2.21 0-4 1.789-4 4v60zm-20 0V60c0-2.211-1.789-4-4-4h-8c-2.21 0-4 1.789-4 4v44zm39.995-28c0-2.211-1.789-4-4-4h-8c-2.21 0-4 1.789-4 4v28h16z\"/></svg>";

/***/ })

}]);