"use strict";
(self["webpackChunkmulti_obs_controller_sdplugin"] = self["webpackChunkmulti_obs_controller_sdplugin"] || []).push([[182],{

/***/ 182:
/***/ ((module) => {

module.exports = "<svg width=\"144\" height=\"144\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M64.568 47.438l13.842-1.634 2.864 9.786-13.85 1.606zM51.93 48.93l2.849 9.733-12.413 1.44-2.26-9.777zm39.119-4.618l9.405-1.11 3.441 9.764-9.974 1.157zM69.113 63.53h13.075l-4.35 10.164h13.075l4.35-10.164h7.985v33.879c0 1.872-1.476 3.39-3.357 3.39H45.65a3.384 3.384 0 01-3.389-3.39v-33.88h13.775l-4.35 10.165h13.075z\" fill=\"#efefef\" fill-rule=\"evenodd\"/></svg>";

/***/ })

}]);