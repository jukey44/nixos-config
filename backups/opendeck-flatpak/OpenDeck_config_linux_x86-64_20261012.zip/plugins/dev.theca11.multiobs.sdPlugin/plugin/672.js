"use strict";
(self["webpackChunkmulti_obs_controller_sdplugin"] = self["webpackChunkmulti_obs_controller_sdplugin"] || []).push([[672],{

/***/ 1672:
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"144\" height=\"144\"><g fill=\"#EFEFEF\"><path d=\"M74 72L50 86V58z\"/><path d=\"M67 96l3 5c-4 2-8 2-12 2-1 0-3-.1-4-.3l2-6c.9.1 2 .1 3 .1 3 0 6-.6 9-2zm-25-3c1 1 3 2 5 3l-2 6c-3-1-5-3-8-4zm35-4c1 2 2 3 4 5-1 2-3 3-4 4l-3-5c1-1 3-2 4-4zm1-31c-5-7-13-11-21-11-13 0-24 10-26 22h8L28 83 17 69h8c2-16 15-28 32-28 10 0 20 5 26 13-2 1-3 3-4 4zM102 52c12 0 22 10 22 22s-10 22-22 22-22-10-22-22 10-22 22-22zm10 30H92v4h20zm-8-10V60h-4v12l-4-4-3 3 9 9 9-9-3-3z\"/></g></svg>";

/***/ })

}]);