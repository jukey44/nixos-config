"use strict";
(self["webpackChunkmulti_obs_controller_sdplugin"] = self["webpackChunkmulti_obs_controller_sdplugin"] || []).push([[270],{

/***/ 5270:
/***/ ((module) => {

module.exports = "<svg width=\"144\" height=\"144\" xmlns=\"http://www.w3.org/2000/svg\"><g fill=\"#efefef\"><path d=\"M102.207 56.897v30.206h-60.41V56.897zm4.315-4.314h-69.04v38.834h69.04z\"/><path d=\"M54.74 78.472h34.52v4.315H54.74zm-8.63 0h4.315v4.315H46.11zm47.465 0h4.315v4.315h-4.316zm-8.63-8.63h4.315v4.316h-4.315zm-8.63 0h4.315v4.316h-4.315zm-8.63 0H72v4.316h-4.317zm-8.63 0h4.315v4.316h-4.315zm-8.63 0h4.315v4.316h-4.315zm30.205-8.63h4.315v4.316H80.63zm8.63 0v4.316h4.315v8.63h4.315V61.212zm-17.26 0h4.315v4.316H72zm-8.63 0h4.315v4.316H63.37zm-8.63 0h4.315v4.316H54.74zm-8.63 0h4.315v4.316H46.11z\"/></g></svg>";

/***/ })

}]);