"use strict";
(self["webpackChunkmulti_obs_controller_sdplugin"] = self["webpackChunkmulti_obs_controller_sdplugin"] || []).push([[947],{

/***/ 3947:
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"144\" height=\"144\"><path fill=\"#efefef\" fill-rule=\"evenodd\" d=\"M113 49v46c0 3.311-2.689 6-6 6H61c-3.311 0-6-2.689-6-6V49c0-3.311 2.689-6 6-6h46c3.311 0 6 2.689 6 6zm-4 0a2 2 0 00-2-2H61a2 2 0 00-2 2v46a2 2 0 002 2h46a2 2 0 002-2V49zM93 74a2 2 0 010-4h1v-7a2 2 0 014 0v7h1a2 2 0 010 4h-6zm5 1v6a2 2 0 01-4 0v-6h4zm-29 3a2 2 0 010-4h1V63a2 2 0 014 0v11h1a2 2 0 010 4h-6zm5 1v2a2 2 0 01-4 0v-2h4zm7-9a2 2 0 010-4h1v-3a2 2 0 014 0v3h1a2 2 0 010 4h-6zm5 1v10a2 2 0 01-4 0V71h4zM47 46v10c0 1.656-1.344 3-3 3H34c-1.656 0-3-1.344-3-3V46c0-1.656 1.344-3 3-3h10c1.656 0 3 1.344 3 3zm0 21v10c0 1.656-1.344 3-3 3H34c-1.656 0-3-1.344-3-3V67c0-1.656 1.344-3 3-3h10c1.656 0 3 1.344 3 3zm-3 0H34v10h10V67zm3 21v10c0 1.656-1.344 3-3 3H34c-1.656 0-3-1.344-3-3V88c0-1.656 1.344-3 3-3h10c1.656 0 3 1.344 3 3zm-3 0H34v10h10V88z\"/></svg>";

/***/ })

}]);