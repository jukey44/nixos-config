"use strict";
(self["webpackChunkmulti_obs_controller_sdplugin"] = self["webpackChunkmulti_obs_controller_sdplugin"] || []).push([[197],{

/***/ 3197:
/***/ ((module) => {

module.exports = "<svg width=\"144\" height=\"144\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#efefef\" fill-rule=\"evenodd\" d=\"M72.728 53.615L29.615 96.728l9.657 9.657 43.113-43.113-9.657-9.657zM95 64l2.971 8.029L106 75l-8.029 2.971L95 86l-2.971-8.029L84 75l8.029-2.971L95 64zm-16.834-.702l-5.464-5.464-10.868 10.868 5.464 5.464 10.868-10.868zM57 36l2.971 8.029L68 47l-8.029 2.971L57 58l-2.971-8.029L46 47l8.029-2.971L57 36zm34-4l2.971 8.029L102 43l-8.029 2.971L91 54l-2.971-8.029L80 43l8.029-2.971L91 32z\"/></svg>";

/***/ })

}]);