"use strict";
(self["webpackChunkmulti_obs_controller_sdplugin"] = self["webpackChunkmulti_obs_controller_sdplugin"] || []).push([[772],{

/***/ 9772:
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"144\" height=\"144\"><path fill=\"#efefef\" fill-rule=\"evenodd\" d=\"M111 62c0-2.208-1.792-4-4-4H52c-2.208 0-4 1.792-4 4v34c0 2.208 1.792 4 4 4h55c2.208 0 4-1.792 4-4V62zm-4 1a1 1 0 00-1-1H53a1 1 0 00-1 1v32a1 1 0 001 1h53a1 1 0 001-1V63zM48 92v-4h-3a1 1 0 01-1-1V55a1 1 0 011-1h53a1 1 0 011 1v3h4v-4c0-2.208-1.792-4-4-4H44c-2.208 0-4 1.792-4 4v34c0 2.208 1.792 4 4 4h4zm54-10H89v9h13v-9zm-62 2v-4h-3a1 1 0 01-1-1V47a1 1 0 011-1h53a1 1 0 011 1v3h4v-4c0-2.208-1.792-4-4-4H36c-2.208 0-4 1.792-4 4v34c0 2.208 1.792 4 4 4h4z\"/></svg>";

/***/ })

}]);