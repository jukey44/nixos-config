"use strict";
(self["webpackChunkmulti_obs_controller_sdplugin"] = self["webpackChunkmulti_obs_controller_sdplugin"] || []).push([[491],{

/***/ 1491:
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"144\" height=\"144\"><path fill=\"#EFEFEF\" fill-rule=\"evenodd\" d=\"M72 104c-17.673 0-32-14.327-32-32 0-17.673 14.327-32 32-32 17.673 0 32 14.327 32 32 0 17.673-14.327 32-32 32zm0-4c15.464 0 28-12.536 28-28S87.464 44 72 44 44 56.536 44 72s12.536 28 28 28zm0-8c-11.046 0-20-8.954-20-20s8.954-20 20-20 20 8.954 20 20-8.954 20-20 20z\"/></svg>";

/***/ })

}]);